public class Password  extends Exception {
    Password(String msg) {
        super(msg);
    }
}
